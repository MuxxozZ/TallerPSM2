/*
 * modulo_semaforo.c
 *
 *  Created on: Octubre, 2024
 *      Author: Patricia y Rodrigo
 */

#include "modulo_semaforo.h"

/**
 * Condición para pasar del estado 1 al estado 2.
 */
static int condicion_estado1_a_estado2(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;
  return HAL_GPIO_ReadPin(semaforo->Switch_Debouncer.GPIOx, semaforo->Switch_Debouncer.GPIO_Pin) == GPIO_PIN_SET;
}

/**
 * Condición para pasar del estado 2 al estado 3.
 */
static int condicion_estado2_a_estado3(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;
  return timer_has_expired(&semaforo->timer);
}

/**
 * Condición para pasar del estado 3 al estado 4.
 */
static int condicion_estado3_a_estado4(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;
  return timer_has_expired(&semaforo->timer);
}

/**
 *  Condición para pasar del estado 4 al estado 1.
 */
static int condicion_estado4_a_estado1(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;
  return timer_has_expired(&semaforo->timer);
}


/**
 * Estado 1: Encender LED verde.
 */
void on_state_estado1(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;

  // Encender el LED verde y apagar el rojo
  HAL_GPIO_WritePin(semaforo->LED_Verde_Blink.LED_Port, semaforo->LED_Verde_Blink.LED_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(semaforo->LED_Rojo_Blink.LED_Port, semaforo->LED_Rojo_Blink.LED_Pin, GPIO_PIN_SET);
}

/**
 *Estado 2: Blink LED verde.
 */
void on_state_estado2(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;

  // Iniciar al timer con una duración de 5s
  timer_start(&semaforo->timer, 5000);
}

/**
 *Estado 3: Encender LED rojo.
 */
void on_state_estado3(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;

  // Apagar el LED verde y encender el rojo
  HAL_GPIO_WritePin(semaforo->LED_Verde_Blink.LED_Port, semaforo->LED_Verde_Blink.LED_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(semaforo->LED_Rojo_Blink.LED_Port, semaforo->LED_Rojo_Blink.LED_Pin, GPIO_PIN_RESET);

  // Iniciar al timer con una duración de 10s
  timer_start(&semaforo->timer, 5000);
}

/**
 * Estado 4: Blink LED rojo.
 */
void on_state_estado4(void *context) {
  ModuloSemaforo *semaforo = (ModuloSemaforo*)context;

  // Iniciar al timer con una duración de 5s
  timer_start(&semaforo->timer, 5000);
}



// Transiciones desde ESTADO_1
static Transition Estado1Transitions[] =
{
    {condicion_estado1_a_estado2, ESTADO_2}, // Transición al estado 2
};

// Transiciones desde ESTADO_2
static Transition Estado2Transitions[] =
{
    {condicion_estado2_a_estado3, ESTADO_3}, // Transición al estado 3
};

// Transiciones desde ESTADO_3
static Transition Estado3Transitions[] =
{
    {condicion_estado3_a_estado4, ESTADO_4} // Transición al estado 1
};

// Transiciones desde ESTADO_4
static Transition Estado4Transitions[] =
{
    {condicion_estado4_a_estado1, ESTADO_1} // Transición al estado 1
};

static FSMState ModuloSemaforoEstados[] =
{
    {Estado1Transitions, 1, on_state_estado1},
    {Estado2Transitions, 1, on_state_estado2},
    {Estado3Transitions, 1, on_state_estado3},
    {Estado4Transitions, 1, on_state_estado4},
};

/**
 * Inicializa el módulo.
 */
void modulo_semaforo_init(ModuloSemaforo *semaforo, GPIO_TypeDef *Luz_Verde_Port,
    uint16_t Luz_Verde_Pin, GPIO_TypeDef *Luz_Roja_Port, uint16_t Luz_Roja_Pin,
    GPIO_TypeDef *SW_Port, uint16_t SW_Pin) {

  blink_control_init(&semaforo->LED_Verde_Blink, Luz_Verde_Port, Luz_Verde_Pin, 500);
  blink_control_init(&semaforo->LED_Rojo_Blink, Luz_Roja_Port, Luz_Roja_Pin, 500);
  debounced_switch_init(&semaforo->Switch_Debouncer, SW_Port, SW_Pin);
  edge_detector_init(&semaforo->Switch_EdgeDetector, &semaforo->Switch_Debouncer);

  fsm_init(&semaforo->fsm, ModuloSemaforoEstados, ESTADO_1, semaforo);

  // Encender el LED verde y apagar el rojo
  HAL_GPIO_WritePin(semaforo->LED_Verde_Blink.LED_Port, semaforo->LED_Verde_Blink.LED_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(semaforo->LED_Rojo_Blink.LED_Port, semaforo->LED_Rojo_Blink.LED_Pin, GPIO_PIN_SET);
}



void modulo_semaforo_update(ModuloSemaforo *semaforo) {
  fsm_update(&semaforo->fsm);

  // Realizar el blink update en los estados 2 y 4
  if (semaforo->fsm.currentState == ESTADO_2) {
    blink_control_update(&semaforo->LED_Verde_Blink);
  }

  if (semaforo->fsm.currentState == ESTADO_4) {
    blink_control_update(&semaforo->LED_Rojo_Blink);
  }
}

